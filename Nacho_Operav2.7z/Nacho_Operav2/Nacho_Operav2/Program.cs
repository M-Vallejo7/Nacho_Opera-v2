﻿using System;
using suma;
using Nacho_Opera;

namespace Nacho_Operav2
{
    class Program
    {
        static void Main(string[] args)
        {
            long rta;
            decimal rt;

            rta = Nacho_Opera.Class1.Multiplicar(5, 2);
            Console.WriteLine(rta.ToString());

            rta = suma.User.suma(5, 2);
            Console.WriteLine(rta.ToString());

            rta = suma.User.resta(5, 2);
            Console.WriteLine(rta.ToString());

            rt = suma.User.division(5, 2);
            Console.WriteLine(rt.ToString());

            Console.ReadKey();
        }
    }
}
